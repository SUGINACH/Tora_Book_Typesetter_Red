'use strict';
const R = process.env.RED_BUILD || process.cwd(); // הריצו מתוך red-build/
const { makeDoc, wait } = require('./shim');
const { createApp } = require(R + '/src/ui/app-shell');
const inline = require(R + '/src/ui/inline-transport');
const { getDefaultSettings } = require(R + '/src/engine/core/settings-registry');
(async () => {
  const app = createApp(makeDoc(), { transport: inline.createInlineTransport() });
  for (const p of app.settingsPanel.root.querySelectorAll('.acc-panel')) {
    const head = p.children[0];
    console.log(String(p.dataset.panelKey).padEnd(10), JSON.stringify((head.textContent || '').trim().slice(0, 34)).padEnd(40), 'ctl', String(p.querySelectorAll('.ctl').length).padStart(3), '| buttons', p.querySelectorAll('button').length, '| selects', p.querySelectorAll('select').length);
  }
  const reg = getDefaultSettings()['body-font'];
  app.getSettings()['body-font'] = 'Bellefair'; app.captureSettingsBaseline();
  app.onResetField('body-font');
  console.log('reset-field: baseline(applied)=Bellefair → after reset =', app.getSettings()['body-font'], '| registry default =', reg);
  process.exit(0);
})();
