# agent1_evidence — ראיות ל-UI_OPERATIONAL_AUDIT.md

מקור: סוכן 1, 10.11.2026. בסיס: main @ 6f80156. Node 22; jsdom 31 (ל-smoke בלבד).

| קובץ | מה הוא |
|---|---|
| `shim.js` | DOM shim — אותו shim של `tests/e2e/s10-ui.test.js` (+ `select.options`) |
| `probe.js` | createApp אמיתי + inline-transport: מבנה, הדבקה⇒עימוד, מה מוצג בממשק, ייצוא, ממצאים, דוח עמוד, שחזור הגדרות, מסמכי בדיקה |
| `probe2.js` | 12 מול 13 פאנלים · היכן מופיע hash הפריסה בממשק · ממצאי UI מול המנוע · גופני תבנית · פענוח cp1255 · הצגת שגיאת מנוע |
| `probe3.js` | כותרות ותוכן הפאנלים · סמנטיקת "איפוס שדה" |
| `smoke-bundle.js` | `ui/index.html` + `ui/app.bundle.js` כפי שנשלחים, ב-jsdom: אתחול + ייבוא TXT (Windows-1255 ו-UTF-8) |
| `*.main.out` | פלט ה-probes על קוד **main** (מצב "לפני") |
| `smoke-main-bundle.out` / `smoke-PR-C-bundle.out` | פלט ה-smoke על ה-bundle של main (לפני) ושל PR-C (אחרי) |

הרצה (מתוך `red-build/` של עץ מלא עם fixtures):

    RED_BUILD=$PWD node <path>/probe.js
    RED_BUILD=$PWD node <path>/probe2.js
    RED_BUILD=$PWD node <path>/probe3.js
    npm i jsdom --prefix /tmp/jsd && NODE_PATH=/tmp/jsd/node_modules RED_BUILD=$PWD node <path>/smoke-bundle.js [תיקיית ui חלופית]

**מגבלה:** אין כאן דפדפן אמיתי, Worker אמיתי או גופנים אמיתיים. ה-probe מכסה לוגיקה ופרוטוקול; ה-smoke מכסה אתחול ונתיב ייבוא.
