'use strict';
// UI operational audit probe (Agent 1) — runs the REAL createApp + inline Worker transport in Node (DOM shim, no browser).
const fs = require('fs');
const crypto = require('crypto');
const R = process.env.RED_BUILD || process.cwd(); // הריצו מתוך red-build/
const { makeDoc, fire, wait } = require('./shim');
const { createApp } = require(R + '/src/ui/app-shell');
const inline = require(R + '/src/ui/inline-transport');
const { BINDINGS } = require(R + '/src/ui/bindings.generated');
const { createSettingsPersistence } = require(R + '/src/ui/settings-persistence');
const { generateTestDocument } = require(R + '/src/ui/test-doc-generator');
const CORPUS = fs.readFileSync(R + '/tests/fixtures/canonical_corpus.txt', 'utf8');
const WITH_FINDING = CORPUS + '\nההתקשרותההתעלותההשגחההתביעה ב.';
const log = (k, v) => console.log(k.padEnd(36), typeof v === 'string' ? v : JSON.stringify(v));
const until = async (fn, ms = 90000) => { const t = Date.now(); while (!fn()) { if (Date.now() - t > ms) throw new Error('timeout'); await wait(25); } };
const mk = (o) => createApp(makeDoc(), Object.assign({ transport: inline.createInlineTransport() }, o || {}));
const paste = (app, t) => fire(app.editor.textarea, 'paste', { clipboardData: { getData: () => t } });
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 12);

(async () => {
  // 1. structure
  const app = mk();
  log('1.tabs', app.root.querySelectorAll('.tabbtn').map(b => b.textContent));
  log('1.settings accordion panels', app.settingsPanel.root.querySelectorAll('.acc-panel').length);
  log('1.controls(.ctl) vs BINDINGS', app.settingsPanel.root.querySelectorAll('.ctl').length + ' / ' + BINDINGS.length);
  const btnLabels = [...new Set(app.root.querySelectorAll('button').map(b => (b.textContent || '').trim()))];
  log('1.distinct button labels', btnLabels.length);
  log('1.cancel/stop control present', btnLabels.some(l => /ביטול|בטל|עצור|cancel|stop/i.test(l)));

  // 2. paste -> progress -> result
  const prog = [];
  const orig = app.status.setEngineState.bind(app.status);
  app.status.setEngineState = (s, i) => { if (s === 'working' && i) prog.push(`${i.pct}|${i.stage}`); orig(s, i); };
  const t0 = Date.now(); paste(app, CORPUS);
  await until(() => app.getState().hasResult);
  const st = app.getState();
  log('2.pages / wall ms (inline)', st.pages + ' / ' + (Date.now() - t0));
  log('2.progress msgs / stages', prog.length + ' / ' + [...new Set(prog.map(x => x.split('|')[1]))].join(','));
  const text = app.root.textContent, html = app.root.outerHTML(), lh = st.layoutHash;
  log('2.layoutHash(prefix)', lh.slice(0, 16));
  log('2.layoutHash shown in UI text', text.includes(lh.slice(0, 12)));
  log('2.layoutHash shown in UI attrs', html.includes(lh.slice(0, 12)));
  log('2.any 16+hex token in UI', /[0-9a-f]{16,}/.test(text) || /[0-9a-f]{16,}/.test(html));
  log('2.status strip', app.status.root.textContent);
  log('2.coverage cards', app.testing.root.querySelectorAll('.coverage-card').map(c => c.textContent));
  log('2.run time shown (ms|שנ|sec)', /\d+(\.\d+)?\s?(ms|שנ|sec|s\b)/i.test(app.status.root.textContent));
  log('2.exportRequest html', Object.keys(app.exportRequest('html') || {}).join(',') + ' ok=' + (app.exportRequest('html') || {}).ok);
  log('2.exportRequest zip', 'ok=' + (app.exportRequest('zip') || {}).ok);
  log('2.exportRequest pdf (no font)', JSON.stringify(app.exportRequest('pdf')));
  app.onSettingChanged('grid-col-width-pct', 45);
  log('2.export while dirty', JSON.stringify(app.exportRequest('zip')));

  // 3. findings -> highlight
  const a3 = mk(); paste(a3, WITH_FINDING); await until(() => a3.getState().hasResult);
  const rows = a3.testing.root.querySelectorAll('.finding-row');
  log('3.finding rows', rows.length);
  if (rows.length) {
    rows[0].dispatchEvent({ type: 'click' });
    log('3.click -> active tab', a3.root.querySelectorAll('.tab-panel').filter(p => p.classList.contains('active')).map(p => p.dataset.tab));
  }
  // 4. per-page report
  const dbg = a3.buildDebugJson(0);
  log('4.page-debug keys', Object.keys(dbg));
  log('4.page-debug slices (ledger/trace/findings)', [dbg.ledger.length, dbg.trace.length, dbg.findings.length]);
  log('4.in-UI per-page debug buttons', a3.preview.root.querySelectorAll('.page-debug-btn').length + ' (download-only; JSON not rendered inline)');

  // 5. settings persistence
  const store = new Map();
  const storage = { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k) };
  const a5 = mk({ settingsPersistence: createSettingsPersistence(storage) }); a5.captureSettingsBaseline();
  a5.onSettingChanged('grid-col-width-pct', 45); log('5.persist now', JSON.stringify(a5.persistSettingsNow()));
  const a6 = mk({ settingsPersistence: createSettingsPersistence(storage) }); a6.captureSettingsBaseline();
  const rr = a6.restorePersistedSettings();
  log('5.restore -> restored/value/gen', [rr.restored, a6.getSettings()['grid-col-width-pct'], a6.getState().gen]);

  // 6. test documents
  const f1 = generateTestDocument({ mode: 'fixed', scale: 'full' }), f2 = generateTestDocument({ mode: 'fixed', scale: 'full' });
  const r1 = generateTestDocument({ mode: 'random', scale: 'full' }), r2 = generateTestDocument({ mode: 'random', scale: 'full' });
  log('6.fixed deterministic / words', [sha(f1) === sha(f2), f1.split(/\s+/).filter(Boolean).length]);
  log('6.random differs', sha(r1) !== sha(r2));

  // 7. template font hazard (does loading a template load/register the fonts it names?)
  const calls = [];
  const fakeLib = { listDesigns: async () => [], ensureDesign: async (c, id) => `imud:${c}:${id}`, listSettingSets: () => [], loadSettingSet: async () => { throw new Error('n/a'); }, loadLegacyDefaults: async () => { throw new Error('n/a'); }, loadFont: async () => null, loadFontStack: async (v) => { calls.push(v); return null; }, fontStatus: () => null, catalogFamilies: () => undefined };
  const a7 = mk({ imudLibrary: fakeLib }); await wait(60);
  const tpl = JSON.stringify({ format: 'tora-typesetter-template', version: 1, settings: Object.assign({}, a7.getSettings(), { 'body-font': 'Bellefair' }) });
  a7.loadTemplateJson(tpl); await wait(60);
  log('7.loadTemplateJson -> font loaded?', calls.includes('Bellefair'));
  calls.length = 0; await a7.applyLegacyDefaults({ 'body-font': 'Bellefair' }, { source: 'panel', retypeset: false });
  log('7.control: applyLegacyDefaults -> loaded?', calls.includes('Bellefair'));
  calls.length = 0; a7.getSettings()['body-font'] = 'Alpha'; storage.setItem('x', '1');

  // 8. TXT import decoding hazard (function-level)
  const bytes = Buffer.from([0xF9, 0xEC, 0xE5, 0xED, 0x20, 0xF2, 0xE5, 0xEC, 0xED]); // "שלום עולם" in windows-1255
  const u = new TextDecoder('utf-8').decode(bytes);
  log('8.cp1255 bytes via utf-8 (readAsText)', u + ' | U+FFFD x' + (u.match(/\uFFFD/g) || []).length);
  log('8.same bytes via windows-1255', new TextDecoder('windows-1255').decode(bytes));

  // 9. engine error display
  let handler = null;
  const failing = { post: (m) => { if (m.type === 'typeset-request') setTimeout(() => handler({ type: 'typeset-error', jobId: m.jobId, message: 'שגיאת בדיקה' }), 5); }, setHandler: (cb) => { handler = cb; }, terminate() {} };
  const a9 = createApp(makeDoc(), { transport: failing }); paste(a9, 'כותרת 1 - א\nטקסט.'); await wait(120);
  log('9.engine error -> status', a9.status.root.textContent);
  process.exit(0);
})().catch(e => { console.error('PROBE FAILED', e); process.exit(1); });
