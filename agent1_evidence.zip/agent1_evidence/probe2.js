'use strict';
const fs = require('fs');
const R = process.env.RED_BUILD || process.cwd(); // הריצו מתוך red-build/
const { makeDoc, fire, wait } = require('./shim');
const { createApp } = require(R + '/src/ui/app-shell');
const inline = require(R + '/src/ui/inline-transport');
const { BINDINGS, PANELS } = require(R + '/src/ui/bindings.generated');
const { typeset } = require(R + '/src/engine/core/pipeline');
const { getDefaultSettings } = require(R + '/src/engine/core/settings-registry');
const { buildReport } = require(R + '/src/audit/report-schema');
const CORPUS = fs.readFileSync(R + '/tests/fixtures/canonical_corpus.txt', 'utf8');
const log = (k, v) => console.log(k.padEnd(36), typeof v === 'string' ? v : JSON.stringify(v));
const until = async (fn, ms = 90000) => { const t = Date.now(); while (!fn()) { if (Date.now() - t > ms) throw new Error('timeout'); await wait(25); } };
const mk = (o) => createApp(makeDoc(), Object.assign({ transport: inline.createInlineTransport() }, o || {}));
const paste = (app, t) => fire(app.editor.textarea, 'paste', { clipboardData: { getData: () => t } });
function where(el, needle, path) {
  path = (path || []).concat((el.className || el.tagName || '').toString().split(' ')[0]);
  const hits = [];
  if (el._text && el._text.includes(needle)) hits.push(path.slice(-4).join('>') + ' :: ' + el._text.slice(0, 110));
  for (const [k, v] of Object.entries(el.attrs || {})) if (String(v).includes(needle)) hits.push(path.slice(-4).join('>') + ' @' + k);
  for (const [k, v] of Object.entries(el.dataset || {})) if (String(v).includes(needle)) hits.push(path.slice(-4).join('>') + ' @data-' + k);
  for (const c of el.children) hits.push(...where(c, needle, path));
  return hits;
}
(async () => {
  const app = mk();
  log('A.PANELS (registry) count', PANELS.length);
  log('A.acc-panel keys in DOM', app.settingsPanel.root.querySelectorAll('.acc-panel').map(p => p.dataset.panelKey || '(no key)'));
  paste(app, CORPUS); await until(() => app.getState().hasResult);
  const lh = app.getState().layoutHash;
  const hits = where(app.root, lh.slice(0, 12));
  log('B.layoutHash locations in UI', hits.length);
  hits.slice(0, 4).forEach(h => console.log('   ', h));
  const direct = buildReport(typeset(CORPUS, getDefaultSettings()));
  log('C.direct engine findings / counts', [direct.findings.length, direct.counts]);
  const uiRows = app.testing.root.querySelectorAll('.finding-row').length;
  log('C.UI finding rows', uiRows);
  log('C.UI card "ממצאים פתוחים"', app.testing.root.querySelectorAll('.coverage-card').map(c => c.textContent).filter(t => /פתוחים/.test(t)));

  // 7. template font hazard
  const calls = [];
  const fakeLib = { listDesigns: async () => [], ensureDesign: async (c, id) => `imud:${c}:${id}`, listSettingSets: () => [], loadSettingSet: async () => { throw new Error('n/a'); }, loadLegacyDefaults: async () => { throw new Error('n/a'); }, loadFont: async () => null, loadFontStack: async (v) => { calls.push(v); return null; }, fontStatus: () => null, catalogFamilies: () => undefined };
  const a7 = mk({ imudLibrary: fakeLib }); await wait(80);
  const tpl = JSON.stringify({ format: 'tora-typesetter-template', version: 1, settings: Object.assign({}, a7.getSettings(), { 'body-font': 'Bellefair' }) });
  a7.loadTemplateJson(tpl); await wait(80);
  log('7.loadTemplateJson -> font loaded?', calls.includes('Bellefair'));
  calls.length = 0; await a7.applyLegacyDefaults({ 'body-font': 'Bellefair' }, { source: 'panel', retypeset: false });
  log('7.control: applyLegacyDefaults -> loaded?', calls.includes('Bellefair'));

  // 8. TXT decoding hazard
  const bytes = Buffer.from([0xF9, 0xEC, 0xE5, 0xED, 0x20, 0xF2, 0xE5, 0xEC, 0xED]);
  const u = new TextDecoder('utf-8').decode(bytes);
  log('8.cp1255 bytes via utf-8 (readAsText)', u + ' | U+FFFD x' + (u.match(/\uFFFD/g) || []).length);
  log('8.same bytes via windows-1255', new TextDecoder('windows-1255').decode(bytes));

  // 9. engine error display
  let handler = null;
  const failing = { post: (m) => { if (m.type === 'typeset-request') setTimeout(() => handler({ type: 'typeset-error', jobId: m.jobId, message: 'שגיאת בדיקה' }), 5); }, setHandler: (cb) => { handler = cb; }, terminate() {} };
  const a9 = createApp(makeDoc(), { transport: failing }); paste(a9, 'כותרת 1 - א\nטקסט.'); await wait(150);
  log('9.engine error -> status', a9.status.root.textContent);
  process.exit(0);
})().catch(e => { console.error('PROBE2 FAILED', e); process.exit(1); });
