'use strict';
// Smoke test of the SHIPPED bundle (ui/index.html + ui/app.bundle.js) in jsdom — boot + TXT import path. No real Worker/fonts/layout.
const { JSDOM } = require('jsdom') /* npm i jsdom (מחוץ לריפו) */;
const fs = require('fs');
const UI = process.argv[2] || ((process.env.RED_BUILD || process.cwd()) + '/ui');
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const log = (k, v) => console.log(k.padEnd(34), typeof v === 'string' ? v : JSON.stringify(v));
(async () => {
  const errors = [];
  const dom = new JSDOM(fs.readFileSync(UI + '/index.html', 'utf8'), { runScripts: 'outside-only', url: 'http://localhost/', pretendToBeVisual: true });
  const w = dom.window;
  w.addEventListener('error', e => errors.push('window.error: ' + e.message));
  const posted = [];
  w.Worker = class { constructor(u) { this.url = u; } postMessage(m) { posted.push(m); } terminate() {} };
  w.fetch = () => Promise.reject(new Error('offline (smoke)'));
  w.URL.createObjectURL = () => 'blob:smoke';
  w.TextDecoder = TextDecoder; // absent in the jsdom window; present in every real browser
  let inputs = [];
  const origClick = w.HTMLInputElement.prototype.click;
  w.HTMLInputElement.prototype.click = function () { if (this.type === 'file') inputs.push(this); else origClick.call(this); };
  w.eval(fs.readFileSync(UI + '/app.bundle.js', 'utf8'));
  await sleep(400);
  const app = w.__toraApp;
  log('boot: app object', !!app);
  log('boot: errors', errors);
  if (!app) process.exit(2);
  const d = w.document;
  log('tabs', [...d.querySelectorAll('.tabbtn')].map(b => b.textContent));
  log('settings panels / label', [d.querySelectorAll('.acc-panel').length, d.querySelector('.settings-count').textContent]);
  log('notice after boot (asset fetch failed)', JSON.stringify(d.querySelector('.chip--notice').textContent));
  log('run chip / run section before run', [JSON.stringify(d.querySelector('.chip--run') ? d.querySelector('.chip--run').textContent : null), d.querySelector('.run-summary') ? d.querySelector('.run-summary').textContent.slice(0, 40) : null]);

  async function importTxt(bytes, name) {
    inputs = []; posted.length = 0;
    [...d.querySelectorAll('button')].find(b => /ייבוא TXT/.test(b.textContent)).click();
    const inp = inputs[inputs.length - 1];
    const file = new w.File([bytes], name, { type: 'text/plain' });
    Object.defineProperty(inp, 'files', { value: [file] });
    inp.dispatchEvent(new w.Event('change'));
    await sleep(250);
    const req = posted.find(m => m.type === 'typeset-request');
    return { editor: app.getText(), notice: d.querySelector('.chip--notice').textContent, sentToEngine: req ? req.text : null };
  }
  const cp = await importTxt(new Uint8Array([0xF9, 0xEC, 0xE5, 0xED, 0x20, 0xF2, 0xE5, 0xEC, 0xED]), 'ansi.txt');
  log('import cp1255 → editor', cp.editor);
  log('import cp1255 → sent to engine', cp.sentToEngine);
  log('import cp1255 → notice', cp.notice);
  const u8 = await importTxt(new Uint8Array(Buffer.from('בראשית ברא', 'utf8')), 'utf8.txt');
  log('import utf-8 → editor / notice', [u8.editor, u8.notice]);
  log('window errors at end', errors);
  process.exit(0);
})().catch(e => { console.error('SMOKE FAILED', e); process.exit(1); });
