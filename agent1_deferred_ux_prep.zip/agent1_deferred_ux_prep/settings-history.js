// src/ui/settings-history.js — היסטוריית ביטול/שחזור להגדרות (סוכן 1, שלב 4.4)
'use strict';

/**
 * טהור (בלי DOM/מנוע): מחסנית שינויי הגדרות של המשתמש. החלת ערך חוזר היא באחריות
 * ה־app (דרך מסלול onSettingChanged הרגיל ⇒ קל/כבד נשמר, F-06 לא מופר).
 * איחוד (coalesce): שינויים רצופים באותו מפתח בתוך חלון קצר (גרירת סליידר/הקלדה)
 * נספרים כשינוי אחד — כדי ש"בטל" יחזיר את הערך שלפני הגרירה, לא צעד זעיר.
 */

function createSettingsHistory(opts) {
  const o = opts || {};
  const limit = o.limit > 0 ? o.limit : 200;
  const coalesceMs = o.coalesceMs != null ? o.coalesceMs : 800;
  const now = typeof o.now === 'function' ? o.now : Date.now;
  let undoStack = [];
  let redoStack = [];
  let lastAt = 0;
  const same = (a, b) => a === b || JSON.stringify(a) === JSON.stringify(b);

  return {
    /** @returns {boolean} האם נרשם שינוי (ערך זהה/ישן לא־מוגדר — לא נרשם). */
    record(key, oldValue, newValue) {
      if (oldValue === undefined || same(oldValue, newValue)) return false;
      const t = now();
      const top = undoStack[undoStack.length - 1];
      redoStack = [];
      if (top && top.key === key && lastAt && (t - lastAt) <= coalesceMs) {
        top.newValue = newValue;
        if (same(top.oldValue, top.newValue)) undoStack.pop(); // חזר לערך המקורי — אין מה לבטל
      } else {
        undoStack.push({ key, oldValue, newValue });
        if (undoStack.length > limit) undoStack.shift();
      }
      lastAt = t;
      return true;
    },
    /** @returns {{key:string,value:any}|null} — הערך להחלה (הישן). */
    undo() {
      const e = undoStack.pop();
      if (!e) return null;
      redoStack.push(e);
      lastAt = 0;
      return { key: e.key, value: e.oldValue };
    },
    redo() {
      const e = redoStack.pop();
      if (!e) return null;
      undoStack.push(e);
      lastAt = 0;
      return { key: e.key, value: e.newValue };
    },
    canUndo: () => undoStack.length > 0,
    canRedo: () => redoStack.length > 0,
    peekUndoKey: () => (undoStack.length ? undoStack[undoStack.length - 1].key : null),
    peekRedoKey: () => (redoStack.length ? redoStack[redoStack.length - 1].key : null),
    clear() { undoStack = []; redoStack = []; lastAt = 0; },
    size: () => ({ undo: undoStack.length, redo: redoStack.length })
  };
}

module.exports = { createSettingsHistory };
