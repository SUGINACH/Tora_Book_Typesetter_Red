// src/ui/hebrew-search.js — חיפוש/החלפה מודע־עברית (סוכן 1, שלב 4.3)
'use strict';

/**
 * טהור: בלי DOM ובלי מנוע (F-06). התאמה סלחנית לעברית:
 *  - ניקוד וטעמי מקרא (U+0591–U+05C7, למעט מקף/פסק/סוף־פסוק) — מתעלמים (ברירת מחדל, ניתן לכבות)
 *  - תווי כיווניות/רוחב־אפס (RLM/LRM/ZWSP/BOM) — תמיד מתעלמים
 *  - גרשיים ומקף מאוחדים: ״≡"  ׳≡'  ־≡-  ומירכאות מסולסלות
 * הטווחים המוחזרים הם במיקומי הטקסט **המקורי** — ניתנים להחלפה ישירה.
 */

const FOLD = {
  '\u05F4': '"', '\u201C': '"', '\u201D': '"', '\u201E': '"',
  '\u05F3': "'", '\u2018': "'", '\u2019': "'",
  '\u05BE': '-'
};

function isInvisible(c) {
  return (c >= 0x200B && c <= 0x200F) || (c >= 0x202A && c <= 0x202E) || (c >= 0x2066 && c <= 0x2069) || c === 0xFEFF;
}
function isMark(c) {
  return (c >= 0x0591 && c <= 0x05BD) || c === 0x05BF || c === 0x05C1 || c === 0x05C2 || c === 0x05C4 || c === 0x05C5 || c === 0x05C7;
}
function skip(c, ignoreMarks) { return isInvisible(c) || (ignoreMarks && isMark(c)); }

/** נרמול + מפה: map[i] = אינדקס התו ה־i של norm בטקסט המקורי. */
function normalize(text, o) {
  const ignoreMarks = !o || o.ignoreMarks !== false;
  const keepCase = !!(o && o.matchCase);
  let norm = '';
  const map = [];
  for (let i = 0; i < text.length; i++) {
    if (skip(text.charCodeAt(i), ignoreMarks)) continue;
    let ch = text[i];
    if (FOLD[ch]) ch = FOLD[ch];
    else if (!keepCase) { const l = ch.toLowerCase(); if (l.length === 1) ch = l; }
    norm += ch;
    map.push(i);
  }
  return { norm, map };
}

const WORD_CH = /[\p{L}\p{N}\p{M}]/u;
function isWordAt(s, i) { return i >= 0 && i < s.length && WORD_CH.test(s[i]); }

/** כל ההתאמות (ללא חפיפה) כ־[{start,end}] במיקומי הטקסט המקורי. */
function findAll(text, query, o) {
  o = o || {};
  const src = String(text == null ? '' : text);
  const q = normalize(String(query == null ? '' : query), o).norm;
  if (!q) return [];
  const { norm, map } = normalize(src, o);
  const ignoreMarks = o.ignoreMarks !== false;
  const out = [];
  let from = 0;
  while (from <= norm.length - q.length) {
    const at = norm.indexOf(q, from);
    if (at < 0) break;
    const endN = at + q.length;
    if (o.wholeWord && (isWordAt(norm, at - 1) || isWordAt(norm, endN))) { from = at + 1; continue; }
    let end = map[endN - 1] + 1;
    // ניקוד/טעמים שצמודים לאות האחרונה שייכים להתאמה (אחרת ההחלפה משאירה "יתומים")
    while (end < src.length && skip(src.charCodeAt(end), ignoreMarks)) end++;
    out.push({ start: map[at], end });
    from = endN;
  }
  return out;
}

function replaceRange(text, range, replacement) {
  return text.slice(0, range.start) + String(replacement) + text.slice(range.end);
}

/** החלפת כל ההתאמות. @returns {{text:string,count:number}} */
function replaceAll(text, query, replacement, o) {
  const ranges = findAll(text, query, o);
  let out = String(text);
  for (let i = ranges.length - 1; i >= 0; i--) out = replaceRange(out, ranges[i], replacement);
  return { text: out, count: ranges.length };
}

/** אינדקס ההתאמה הבאה/הקודמת ממיקום pos (עם גלישה); -1 אם אין. dir>=0 קדימה. */
function pickMatch(ranges, pos, dir) {
  if (!ranges.length) return -1;
  if (dir >= 0) {
    for (let i = 0; i < ranges.length; i++) if (ranges[i].start >= pos) return i;
    return 0;
  }
  for (let i = ranges.length - 1; i >= 0; i--) if (ranges[i].end <= pos) return i;
  return ranges.length - 1;
}

module.exports = { normalize, findAll, replaceAll, replaceRange, pickMatch };
